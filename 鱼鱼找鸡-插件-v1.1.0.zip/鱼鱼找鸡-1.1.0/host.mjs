/**
 * 鱼鱼找鸡 · OneBot 11 宿主
 * 用途：让「鱼鱼找鸡」挂在一个 QQ 机器人上（NapCat / LLOneBot / Lagrange 都行）。
 *
 * 只用了 Node 自带的东西：WebSocket 连机器人，发消息也走同一条连接。
 * 不需要 npm install，不需要公网 IP，不需要另开 HTTP 服务。
 *
 * 用法：
 *   1) 机器人那边开一个「WebSocket 服务器」，记下端口和 token
 *   2) 本文件同目录建 host.config.json（或直接改下面的默认值）
 *   3) node host.mjs
 *
 * 例（Windows PowerShell）：
 *   $env:ONEBOT_WS="ws://127.0.0.1:3001"; $env:ONEBOT_TOKEN="你的token"; node host.mjs
 */
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleFishCommand } from './adapters/onebot.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));

const DEFAULTS = {
  // 机器人那边的 WebSocket 服务器地址
  ws: 'ws://127.0.0.1:3001',
  // 机器人那边的 token（留空 = 不校验）
  token: '',
  // 触发词，必须和插件里的 /鱼鱼找鸡 一致
  prefix: '鱼鱼找鸡',
  // 只在这些群里干活，留空 = 所有群 + 私聊都接（建议填上，防止被人拉进陌生群白嫖额度）
  allowedGroups: [],
  // 只理这些人，留空 = 不限制。填 QQ 号
  allowedUsers: [],
  // 自己发的消息也处理？默认 false
  selfTrigger: false,
  log: true,
};

function loadConfig() {
  const cfg = { ...DEFAULTS };
  const file = path.join(HERE, 'host.config.json');
  if (existsSync(file)) {
    try {
      Object.assign(cfg, JSON.parse(readFileSync(file, 'utf8')));
    } catch (error) {
      console.warn('[host] host.config.json 读不了，用默认值：', error?.message ?? error);
    }
  }
  // 环境变量优先级最高：临时换个地址/端口不用改文件
  if (process.env.ONEBOT_WS) cfg.ws = process.env.ONEBOT_WS;
  if (process.env.ONEBOT_TOKEN) cfg.token = process.env.ONEBOT_TOKEN;
  return cfg;
}

const cfg = loadConfig();

if (typeof WebSocket !== 'function') {
  console.error(
    '[host] 这个 Node 没有内置 WebSocket（需要 Node 22 以上）。\n' +
      `      当前版本：${process.version}\n` +
      '      去 https://nodejs.org 下 LTS 版装上，重开一个命令行再跑。'
  );
  process.exit(1);
}

const log = (...args) => {
  if (cfg.log) console.log('[host]', ...args);
};

let sock = null;
let seq = 0;
let retries = 0;
const pending = new Map();

/** 调 OneBot 动作（send_group_msg / get_msg …），走 WS 的 echo 回包。 */
function callAction(action, params = {}) {
  return new Promise((resolve, reject) => {
    if (!sock || sock.readyState !== 1) {
      reject(new Error('还没连上机器人'));
      return;
    }
    const echo = `fish-${Date.now()}-${++seq}`;
    const timer = setTimeout(() => {
      if (pending.delete(echo)) reject(new Error(`${action} 超时（30 秒没回）`));
    }, 30000);
    pending.set(echo, { resolve, reject, timer });
    sock.send(JSON.stringify({ action, params, echo }));
  });
}

function connect() {
  // OneBot 的 token 走 query，比塞 header 稳（Node 自带 WebSocket 不支持自定义 header）
  let url = cfg.ws;
  if (cfg.token && !/[?&]access_token=/.test(url)) {
    url += (url.includes('?') ? '&' : '?') + `access_token=${encodeURIComponent(cfg.token)}`;
  }
  log('连接', cfg.ws);
  sock = new WebSocket(url);

  sock.addEventListener('open', () => {
    retries = 0;
    log('已连上机器人，等 /鱼鱼找鸡');
  });

  sock.addEventListener('message', (event) => {
    let payload = null;
    try {
      payload = JSON.parse(typeof event.data === 'string' ? event.data : '');
    } catch {
      return;
    }
    if (!payload) return;

    // 动作的回包
    if (payload.echo) {
      const waiter = pending.get(payload.echo);
      if (!waiter) return;
      pending.delete(payload.echo);
      clearTimeout(waiter.timer);
      if (payload.status === 'failed' || (payload.retcode !== undefined && payload.retcode !== 0)) {
        waiter.reject(new Error(payload.message || payload.wording || `retcode=${payload.retcode}`));
      } else {
        waiter.resolve(payload);
      }
      return;
    }

    // 事件推送
    onEvent(payload).catch((error) => console.warn('[host] 处理事件出错：', error?.message ?? error));
  });

  sock.addEventListener('close', () => {
    for (const [, waiter] of pending) {
      clearTimeout(waiter.timer);
      waiter.reject(new Error('连接断了'));
    }
    pending.clear();
    const wait = Math.min(30000, 1000 * 2 ** Math.min(retries++, 5));
    log(`连接断开了，${Math.round(wait / 1000)} 秒后重连`);
    setTimeout(connect, wait);
  });

  sock.addEventListener('error', () => {}); // 交给 close 处理，别刷屏
}

async function onEvent(event) {
  if (event?.post_type === 'meta_event') return;
  if (event?.post_type !== 'message') return;

  const message = event.message;
  if (typeof message === 'string') {
    console.warn(
      '[host] 机器人推过来的是 CQ 码字符串，插件只认数组。\n' +
        '      去 NapCat 的「网络配置 → WebSocket 服务器」把「消息格式」改成 array，然后重连。'
    );
    return;
  }
  if (!Array.isArray(message)) return;

  // 插件靠 event.reply.id 找被引用的那张图；不同实现字段不一样，这里统一补上
  const replySegment = message.find((segment) => segment?.type === 'reply');
  if (replySegment && !event.reply) event.reply = { id: replySegment.data?.id };

  const text = String(event.raw_message ?? '').trim();
  if (!text.includes(cfg.prefix)) return;

  const inGroup = Boolean(event.group_id);
  if (inGroup && cfg.allowedGroups.length && !cfg.allowedGroups.map(Number).includes(Number(event.group_id))) return;
  if (!inGroup && cfg.allowedUsers.length && !cfg.allowedUsers.map(Number).includes(Number(event.user_id))) return;

  const key = inGroup ? `group:${event.group_id}` : `private:${event.user_id}`;
  log(`${key} ← ${event.user_id}「${text}」`);
  try {
    const result = await handleFishCommand({ text, key, event, onebot: callAction });
    if (result?.handled) log('已回话');
  } catch (error) {
    console.warn('[host] 这条没处理成：', error?.message ?? error);
    try {
      await callAction(inGroup ? 'send_group_msg' : 'send_private_msg', inGroup
        ? { group_id: Number(event.group_id), message: `出错了：${error?.message ?? error}` }
        : { user_id: Number(event.user_id), message: `出错了：${error?.message ?? error}` });
    } catch {}
  }
}

connect();

process.on('SIGINT', () => {
  log('手动退出');
  try {
    sock?.close();
  } catch {}
  process.exit(0);
});
