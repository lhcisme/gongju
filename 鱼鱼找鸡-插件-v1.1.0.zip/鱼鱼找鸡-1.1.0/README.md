# 鱼鱼找鸡 v1.0.0

给一张图，反查这人是哪个 coser、账号在哪。

- 多引擎：**谷歌 Lens**（最准，能抓到推特主页）、SauceNAO（动漫/同人）、trace.moe（动漫截屏）、IQDB、百度识图。
- 零 token：不调用任何大模型，**不花 API 钱**。
- 不依赖 npm 包（只用 Node 内置模块 + 本机已装的 Edge/Chrome）。

---

## 1. 装环境

| 需要 | 说明 |
|---|---|
| Node.js ≥ 20（接 QQ 机器人要 ≥ 22） | 内置 `fetch`、`WebSocket`，不用装依赖 |
| Edge 或 Chrome | 谷歌 Lens 那条路要开一个无头浏览器（Windows 自带 Edge 就够） |
| 外网（可选） | 只用 SauceNAO / trace.moe 的话，国内直连也能用 |

```bash
node bin/fish.mjs --check
```

## 2. 配配置

```bash
copy config.example.json config.json
```

| 配置 | 什么时候改 |
|---|---|
| `engines` | 想加/减引擎。默认 `lens,saucenao,tracemoe` |
| `proxy` | 机器上没全局代理、但你有本地代理端口（clash 7890、猫猫云 10090…）时填，只让浏览器走它 |
| `strictConsensus` | 想「宁可多报」就设 false |
| `foundImage` | 想命中时顺带发张图（比如一张「找到了」的表情） |

## 3. 用

```bash
# 查本机图片
node bin/fish.mjs D:/图片/a.jpg

# 查网址
node bin/fish.mjs https://example.com/a.jpg

# 只看结构化结果（方便自己接脚本）
node bin/fish.mjs D:/图片/a.jpg --json

# 只走直连引擎（不开浏览器、不碰外网）
node bin/fish.mjs D:/图片/a.jpg --engines saucenao,tracemoe

# 名字对不上也报（自己挑）
node bin/fish.mjs D:/图片/a.jpg --no-strict
```

输出长这样：

```
🎯 鱼鱼找鸡结果

🌐 平台：Twitter
👤 名字：阿薰kaOri
🆔 账号：@izayoill · https://x.com/izayoill
```

### 它是怎么认的（也是「为什么有时候查不到」的原因）

1. 各引擎返回「相似图的所在页面」；
2. 从页面里抽社交账号（推特/微博/B站/Instagram/小红书…），作者页比帖子页可信；
3. 同一角色常有好几个 coser，只留「标题里出现同一个人名」的那一撮（`strictConsensus`）；
4. 画作平台（pixiv）容易把画师当 coser，相似度不够的会丢掉——所以偶尔会明说「只翻到相似画作」。

## 4. 挂进 QQ 机器人（OneBot 11）

整条链路是：**QQ 客户端 ← NapCat ← WebSocket → host.mjs（本插件）**。中间不用买服务器、不用公网 IP。

### 4.1 装一个 OneBot 实现

| 选 | 说明 |
|---|---|
| **NapCatQQ** | 推荐。有 Windows 一键包，扫码登录，WebUI 里点几下配好 |
| LLOneBot | LiteLoaderQQNT 插件，已经装了 QQNT 的可以用 |
| Lagrange.OneBot | 能跑，但生态冷清 |

> `go-cqhttp` 已停止维护、登不上，别照老教程找它。

### 4.2 在 NapCat 里开一个 WebSocket 服务器

1. 启动 NapCat → 打开 WebUI（默认 `http://127.0.0.1:6099`，token 在启动窗口里打印）；
2. **手机 QQ 扫码**登录机器人号；
3. 「网络配置」→ 新增 → **WebSocket 服务器**：端口 `3001`，token 自己设一个（例如 `fish123`）；
4. **消息格式选 `array`**（关键，选 `string` 插件读不到图片段）；
5. 保存 → 重启 NapCat。

### 4.3 填 `host.config.json`

```json
{
  "ws": "ws://127.0.0.1:3001",
  "token": "fish123",
  "allowedGroups": [123456789]
}
```

`allowedGroups` 不填 = 所有群和私聊都接单，容易被拉进陌生群白嫖 SauceNAO 免费额度，建议填上群号。

### 4.4 跑起来

```bash
node host.mjs
```

看到这两行就成了：

```
[host] 已连上机器人，等 /鱼鱼找鸡
```

需要 **Node 22 以上**（用的是 Node 自带的 WebSocket，不装任何依赖）。

### 4.5 用

群里**引用一条带图的消息** → 发 `/鱼鱼找鸡`。
它先回「收到，开始找鸡」，查完再回结果；`foundImage` 配了表情包的话，图和文一条发出去。

### 4.6 QQ 场景的三个坑

- **机器人号建议用小号**。个人号挂第三方协议有封号风险，别拿常用号试。
- **图片是腾讯内网 rkey**：`bing / yandex / baidu / google` 这几个引擎只吃公网图片 URL，在 QQ 里会直接报「需要公网图片 URL」。能用的只有 `saucenao / iqdb / tracemoe / lens`。
- **Linux/macOS 上没有 Edge**：`lens` 会用不了。把 `config.json` 的 `engines` 改成 `["saucenao", "tracemoe"]`，省一次白跑。

## 5. 常见问题

**Lens 一直没结果 / 报 `GOOGLE_UNREACHABLE`**
谷歌连不上。要么开系统代理，要么在 `config.json` 填 `proxy`（只让浏览器走，不动系统代理）。

**报 `GOOGLE_CAPTCHA`**
谷歌要人机验证。用 `--proxy` 换个出口，或者先用 `--engines saucenao,tracemoe` 顶着。

**第一次跑很慢**
无头浏览器冷启动要 2~4 秒；它会复用同一个 profile 目录（`state/`），第二次就快。

**SauceNAO 报 429**
免费额度被刷完了，等一会儿，或者少查几张。

**查到一堆别人的号**
保持 `strictConsensus: true`（默认）。它是「只报标题里出现同一个名字的人」。

**图片会不会被上传到网上**
会——反查必须把图发给引擎（SauceNAO/Lens/百度…）。上传目标写死在 `src/fish-find-chicken.js` 的 `UPLOAD_HOSTS` 白名单里，不读配置，防止被配置改去奇怪的域名。不想上传就别用。

## 6. 隐私与许可

- 不收集、不上报任何使用数据；所有请求只发给你配置在引擎白名单里的域名。
- 浏览器 profile 存在插件目录 `state/` 下，只用来复用谷歌的验证 cookie，可以随时删。
- 代码 MIT。

---

版本 1.0.0 · 文件名 `coser-image-search`
